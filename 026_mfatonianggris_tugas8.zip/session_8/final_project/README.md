# 🛍️ Product Landing Page
**Project within:** Responsive Web Design Certification by Free Code Camp <a href="https://www.freecodecamp.org/learn/responsive-web-design/responsive-web-design-projects/build-a-product-landing-page/">View Certification</a>


**Objective:** Build a Product Landing Page

**Requirements:** <a href="https://www.freecodecamp.org/learn/responsive-web-design/responsive-web-design-projects/build-a-product-landing-page/">View Requirements</a>

**Solution Link:** <a href="https://cosminmoldovan.github.io/fcc-product-landing-page/">Live Demo</a>

<img src="project-thumbnail.png" />